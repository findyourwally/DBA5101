This is the DBA5101 Analytics in Managerial Economics github repository of Group 40 belonging to:
- Chung Yeonjong
- Lim Ciwen Brendan
- Matthieu Simon Bernard Zekhout
- Tey Ming Chuan
